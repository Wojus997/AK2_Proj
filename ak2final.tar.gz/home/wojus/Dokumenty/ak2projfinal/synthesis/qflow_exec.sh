#!/usr/bin/tcsh -f
#-------------------------------------------
# qflow exec script for project /home/wojus/Dokumenty/ak2projfinal/synthesis
#-------------------------------------------

# /usr/lib/qflow/scripts/synthesize.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
 #/usr/lib/qflow/scripts/placement.sh -d /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
 #/usr/lib/qflow/scripts/vesta.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
 #/usr/lib/qflow/scripts/router.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
 #/usr/lib/qflow/scripts/placement.sh -f -d /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
 #/usr/lib/qflow/scripts/router.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1 $status
#/usr/lib/qflow/scripts/cleanup.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
/usr/lib/qflow/scripts/display.sh /home/wojus/Dokumenty/ak2projfinal/synthesis Adder || exit 1
