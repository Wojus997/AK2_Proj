#!/usr/bin/tcsh -f
#-------------------------------------------
# qflow variables for project /home/wojus/Dokumenty/ak2projfinal/synthesis
#-------------------------------------------

set projectpath=/home/wojus/Dokumenty/ak2projfinal/synthesis
set techdir=/usr/share/qflow/tech/osu035
set sourcedir=/home/wojus/Dokumenty/ak2projfinal/synthesis
set synthdir=/home/wojus/Dokumenty/ak2projfinal/synthesis
set layoutdir=/home/wojus/Dokumenty/ak2projfinal/synthesis
set techname=osu035
set scriptdir=/usr/lib/qflow/scripts
set bindir=/usr/lib/qflow/bin
set synthlog=/home/wojus/Dokumenty/ak2projfinal/synthesis/synth.log
#-------------------------------------------

