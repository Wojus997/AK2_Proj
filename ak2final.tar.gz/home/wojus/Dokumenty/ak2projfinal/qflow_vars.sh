#!/usr/bin/tcsh -f
#-------------------------------------------
# qflow variables for project /home/wojus/Dokumenty/ak2projfinal
#-------------------------------------------

set projectpath=/home/wojus/Dokumenty/ak2projfinal
set techdir=/usr/share/qflow/tech/osu050
set sourcedir=/home/wojus/Dokumenty/ak2projfinal/source
set synthdir=/home/wojus/Dokumenty/ak2projfinal/synthesis
set layoutdir=/home/wojus/Dokumenty/ak2projfinal/layout
set techname=osu050
set scriptdir=/usr/lib/qflow/scripts
set bindir=/usr/lib/qflow/bin
set synthlog=/home/wojus/Dokumenty/ak2projfinal/synth.log
#-------------------------------------------

